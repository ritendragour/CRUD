# CRUD-in-PHP

localhost/index.php
