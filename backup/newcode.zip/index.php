<?php
header('location:./info/login.php');
?>